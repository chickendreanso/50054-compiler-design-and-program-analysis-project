package sutd.compiler.simp.syntax

object SrcLoc {
    case class SrcLoc(line:Int, col:Int)
}